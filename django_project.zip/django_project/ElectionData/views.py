from django.shortcuts import render
from django.forms import modelform_factory
from django.http import HttpResponse
from .models import Elections,Selection

# Create your views here.
def ElectionData(request):
    return render(request, "ElectionData/Data.html",
                  {"Electionlist" : Elections.objects.count()})   


ElectionsForm=modelform_factory(Elections,fields=('states',))


def new(request):
    form = ElectionsForm()
    print("the request came in")
    print(form)
    input = form.fields
    input in Elections.objects.all()
    print(input)
    # output = Elections.objects.filter( states == input )
    # print(output)
    return render(request, "ElectionData/new.html", {"form": form})

    
#def new(request):
    # if request.method == "POST":
    #     form = ElectionsForm()
    #     if form.is_valid():
    #         #groups = Elections.objections.select_related('states')
    #         return HttpResponse("hello")
            
    # else:
    #     form = ElectionsForm()
    # return render(request, "ElectionData/new.html", {"form": form})

