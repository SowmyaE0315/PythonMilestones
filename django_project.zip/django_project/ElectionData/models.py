from django.db import models

class Elections(models.Model):
# Create your models here.
    states = models.CharField(max_length=200)
    HouseOfReps=models.IntegerField(default=0)
    ElectoralValue=models.IntegerField(default=0)
    Senates=models.IntegerField(default=0)
    
    def __str__(self):
        return f"{self.states}: reps {self.HouseOfReps} , electorals {self.ElectoralValue} and senates {self.Senates}"

class Selection(models.Model):
        selection = models.CharField(max_length=200)

        def __str__(self):
            return f"{self.selection}"
        
        


     